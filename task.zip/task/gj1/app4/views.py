from django.shortcuts import render,redirect
from django.http import HttpResponse

from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseBadRequest
from app4.models import *

def nav(request):
    return render(request,'nav.html')
def home(request):
    return render(request,'home.html')

def registration(request):
    if request.method=="POST":
        name1=request.POST['name']
        email1=request.POST['email']
        number1=request.POST['number']
        address1=request.POST['address']
        pass1=request.POST['pswds']
        user=Userregisters(name=name1,email=email1,number=number1,address=address1,password=pass1)
        print(Userregisters.objects.filter(email=email1).exists())
        if len(Userregisters.objects.filter(email=email1)) ==0:
            user.save()
        return redirect('login1')
    else:
        return render(request,'registration.html',{'m':"user alredy exist"})

def login(request):
    if request.method=="POST":
        email1=request.POST['email']
        pass1=request.POST['pswds']
        try:
            user=Userregisters.objects.get(email=email1,password=pass1)
            if user:
                request.session['email']=user.email
                request.session['id']=user.pk
                return redirect('nav1')
            else:
                return render(request,'login.html',{'m':"invalid userid and password"})
        except:
            return render(request,'login.html',{'m':"invalid data enter"})
    return render(request,'login.html')

      
  

def contactus(request):
    if request.method=="POST":
        name1=request.POST['name']
        email1=request.POST['email']
        phone1=request.POST['phone']
        msg1=request.POST['mess']
        user=message12(name=name1,email=email1,phone=phone1,message=msg1)
        user.save()
    return render(request,'contactus.html')

def booknow(request):
    
    return render(request,'booknow.html')

def book1(request):
    return render(request,'book1.html')

def book2(request):
    return render(request,'book2.html')

def paynow(request):
    return render(request,'paynow.html')

def commingsoon(request):
    return render(request,'commingsoon.html')