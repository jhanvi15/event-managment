from django.contrib import admin

# Register your models here.
from app4.models import *
class userdisplay(admin.ModelAdmin):
   list_display=['name','email','number','address']
   search_fields=['name']
admin.site.register(Userregisters,userdisplay)

admin.site.register(message12)
