from django.urls import path
from app4.views import *

urlpatterns = [
      path('',nav,name="nav1"),
      path('home/',home,name="home1"),
      path('login/',login,name="login1"),
      path('registration/',registration,name="res1"),
      path('contactus/',contactus,name="con1"),
      path('booknow/', booknow ,name="book1"),
      path('book1/', book1 ,name="book2"),
      path('book2/', book2 ,name="book3"),
      path('paynow/', paynow ,name="paynow1"),
      path('commingsoon/', commingsoon ,name="comming1"),
]
